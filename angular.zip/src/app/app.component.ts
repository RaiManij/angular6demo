import { Component } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-app';
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  events: string[] = [];
  opened: boolean;
  autoTicks = false;
  disabled = false;
  invert = false;
  max = 100;
  min = 0;
  showWizard:boolean=false;
  showWizardInfo:boolean=false;
  hidePrint:boolean=true;
  hidePrintVal:boolean=true;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  value = 0;
  vertical = false;

  model:object={"Options":"red"};
  powers:string[]=["red","green","yellow","blue"];
  countries:string[]=["Nepal","India","China"];
  menuList:string[]=["Sign in","Reset Your Design","About Our Labels","Pricing","Refund Policy","Privacy Policy","Report a Bug","Contact Us"];
  constructor(private _formBuilder: FormBuilder) {}
  showWizardHandler(){
    this.showWizard = true;
    this.showWizardInfo = true;
  }
  backHandler(){
    this.showWizardInfo = false;
    this.hidePrint = true;
    this.hidePrintVal = true;
    this.showWizard = false;
  }
  showPrint(param1,param2){
    this.hidePrint = param1;
    this.hidePrintVal = param2;
    this.showWizardInfo = true;
  }
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['']
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: [''],
      secondCtrl2:[''],
      secondCtrl23:[''],
      secondCtrl233:[''],
      secondCtrl2343:[''],
      secondCtrl2334:['']
    });
  }
}
